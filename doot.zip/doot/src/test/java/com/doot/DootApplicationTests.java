package com.doot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DootApplicationTests {

	@Test
	void contextLoads() {
	}

}
